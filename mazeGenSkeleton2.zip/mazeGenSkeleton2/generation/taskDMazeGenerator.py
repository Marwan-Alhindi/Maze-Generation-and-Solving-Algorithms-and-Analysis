# -------------------------------------------------------------------
# PLEASE UPDATE THIS FILE.
# Implementation of Task D maze generator.
#
# __author__ = 'Jeffrey Chan'
# __copyright__ = 'Copyright 2024, RMIT University'
# -------------------------------------------------------------------
from maze.maze3D import Maze3D
from maze.util import Coordinates3D
from generation.mazeGenerator import MazeGenerator
import random
from collections import deque
import heapq

class TaskDMazeGenerator(MazeGenerator):
    """
    Generates a 3D maze designed to create worst-case scenarios for Wall Following, 
    Depth-First Search, and Dijkstra's algorithms. The generator uses recursive 
    backtracking to create a complex maze layout with many dead ends and specific 
    complexities to challenge various maze-solving algorithms.
    """
    
    def generateMaze(self, maze: Maze3D):
        """
        Initializes a maze with full walls and progressively removes certain walls 
        to create a complex maze structure using recursive backtracking.

        Args:
            maze (Maze3D): The 3D maze object to be modified.
        """
        maze.initCells(True)  # Start with a fully walled maze
        random.seed(42)  # Seed for reproducibility
        self.arrow_direction_tracker = 'front'  # Initial direction tracker for arrow maze modifications
        levels = maze.levelNum()
        rows = maze.rowNum(0)
        cols = maze.colNum(0)

        # Select a random starting point for the maze generation
        startLevel = random.randint(0, levels - 1)
        startRow = random.randint(0, rows - 1)
        startCol = random.randint(0, cols - 1)
        startCoord = Coordinates3D(startLevel, startRow, startCol)

        # Use a stack to manage the cells during the recursive backtracking
        stack = [startCoord]
        visited = set([startCoord])

        while stack:
            current = stack[-1]
            neighbours = [n for n in maze.neighbours(current) if n not in visited and self.isValidCell(n, levels, rows, cols)]
            
            if neighbours:
                next_cell = random.choice(neighbours)
                maze.removeWall(current, next_cell)  # Remove the wall to create a path
                visited.add(next_cell)
                stack.append(next_cell)
            else:
                stack.pop()  # Backtrack if no unvisited neighbours are found

        self.addComplexity(maze, visited)  # Introduce additional complexity
        self.addBoundaries(maze)  # Ensure the boundaries are properly set
        self.m_mazeGenerated = True  # Flag to indicate the maze generation is complete

    def isValidCell(self, cell, levels, rows, cols):
        """
        Validates if the specified cell is within the bounds of the maze dimensions.

        Args:
            cell (Coordinates3D): The cell to validate.
            levels (int): Total number of levels in the maze.
            rows (int): Number of rows per level.
            cols (int): Number of columns per level.

        Returns:
            bool: True if the cell is within bounds, otherwise False.
        """
        return 0 <= cell.getLevel() < levels and 0 <= cell.getRow() < rows and 0 <= cell.getCol() < cols

    def arrow_direction(self, x, count):
        """
        Determines the direction of movement based on the current and previous cell positions to adjust the neighbor sorting logic.

        Args:
            x (list[Coordinates3D]): List of cells representing the path.
            count (int): Index of the current cell in the path.
        """
        # Update the direction tracker based on relative position of consecutive cells
        if x[count-1].getCol() - x[count].getCol() == 1:
            self.arrow_direction_tracker = 'left'
        elif x[count-1].getCol() - x[count].getCol() == -1:
            self.arrow_direction_tracker = 'right'
        elif x[count-1].getRow() - x[count].getRow() == 1:
            self.arrow_direction_tracker = 'below'
        elif x[count-1].getRow() - x[count].getRow() == -1:
            self.arrow_direction_tracker = 'front'

    def neighbours_sort(self, neighbours: list[Coordinates3D]):
        """
        Sorts the neighbours list based on the current direction of movement.

        Args:
            neighbours (list[Coordinates3D]): The list of neighboring cells to be sorted.
        """
        if self.arrow_direction_tracker == 'front':
            if len(neighbours) == 6:
                neighbours[:] = [neighbours[0], neighbours[3], neighbours[1], neighbours[2], neighbours[4], neighbours[5]]
            elif len(neighbours) == 5:
                neighbours[:] = [neighbours[0], neighbours[3], neighbours[1], neighbours[2], neighbours[4]]
        elif self.arrow_direction_tracker == 'left':
            if len(neighbours) == 6:
                neighbours[:] = [neighbours[2], neighbours[0], neighbours[3], neighbours[1], neighbours[4], neighbours[5]]
            elif len(neighbours) == 5:
                neighbours[:] = [neighbours[2], neighbours[0], neighbours[3], neighbours[1], neighbours[4]]
        elif self.arrow_direction_tracker == 'right':
            if len(neighbours) == 6:
                neighbours[:] = [neighbours[3], neighbours[1], neighbours[2], neighbours[0], neighbours[4], neighbours[5]]
            elif len(neighbours) == 5:
                neighbours[:] = [neighbours[3], neighbours[1], neighbours[2], neighbours[0], neighbours[4]]
        elif self.arrow_direction_tracker == 'below':
            if len(neighbours) == 6:
                neighbours[:] = [neighbours[1], neighbours[2], neighbours[0], neighbours[3], neighbours[4], neighbours[5]]
            elif len(neighbours) == 5:
                neighbours[:] = [neighbours[1], neighbours[2], neighbours[0], neighbours[3], neighbours[4]]

    def addComplexity(self, maze, visited):
        """
        Adds additional complexity to the maze after the initial generation. This includes creating more dead ends
        and loops specifically to challenge different types of maze-solving algorithms.

        Args:
            maze (Maze3D): The maze to modify.
            visited (set[Coordinates3D]): Set of cells that have been visited during the initial maze generation.
        """
        # Complexity 1: Increase the number of turns for wall following algorithms
        correct_cells = list(maze.allCells())
        count = -1
        for cell in correct_cells:
            count += 1
            self.arrow_direction(correct_cells, count)
            neighbors = maze.neighbours(cell)
            self.neighbours_sort(neighbors)
            if len(neighbors) > 2:
                if maze.hasWall(cell, neighbors[0]):
                    if maze.hasWall(cell, neighbors[1]):
                        if maze.hasWall(cell, neighbors[2]):
                            if maze.hasWall(cell, neighbors[3]):
                                continue
                            else:
                                if not self.tryAddWall(maze, cell, neighbors[3]):
                                    continue
                        else:
                            if not self.tryAddWall(maze, cell, neighbors[2]):
                                continue
                    else:
                        if not self.tryAddWall(maze, cell, neighbors[1]):
                            continue
                else:
                    if not self.tryAddWall(maze, cell, neighbors[0]):
                        continue

        # Complexity 2: Add additional dead ends to make DFS harder
        for cell in list(visited):
            neighbours = [n for n in maze.neighbours(cell) if self.isValidCell(n, maze.levelNum(), maze.rowNum(0), maze.colNum(0))]
            if len(neighbours) > 2 and random.random() < 0:  # Create dead ends for 30% of the visited cells
                neighbours_to_block = random.sample(neighbours, len(neighbours) - 1)
                for neighbour in neighbours_to_block:
                    if self.tryAddWall(maze, cell, neighbour):
                        break

    def tryAddWall(self, maze, cell, neighbour):
        """
        Attempts to add a wall between two cells if it doesn't make the maze unsolvable.

        Args:
            maze (Maze3D): The maze to modify.
            cell (Coordinates3D): The current cell.
            neighbour (Coordinates3D): The neighboring cell to potentially separate with a wall.

        Returns:
            bool: True if the wall was added, otherwise False.
        """
        maze.addWall(cell, neighbour)
        if not self.isMazeSolvable(maze):
            maze.removeWall(cell, neighbour)
            return False
        return True

    def isMazeSolvable(self, maze: Maze3D) -> bool:
        """
        Check if the maze is solvable using Dijkstra's algorithm.
        """
        entrances = maze.getEntrances()
        exits = maze.getExits()

        for entrance in entrances:
            pq = [(0, entrance)]  # (cost, node)
            heapq.heapify(pq)
            visited = set()

            while pq:
                cost, current = heapq.heappop(pq)
                if current in exits:
                    return True
                if current not in visited:
                    visited.add(current)
                    for neighbor in maze.neighbours(current):
                        if neighbor not in visited and not maze.hasWall(current, neighbor):
                            heapq.heappush(pq, (cost + 1, neighbor))
        return False

    def addBoundaries(self, maze):
        """
        Ensures the outer boundaries of the maze are intact, except for designated entrance and exit points.

        Args:
            maze (Maze3D): The maze to modify.
        """
        rows = maze.rowNum(0)
        cols = maze.colNum(0)

        for level in range(maze.levelNum()):
            for c in range(cols):
                # Top and bottom boundaries
                maze.addWall(Coordinates3D(level, 0, c), Coordinates3D(level, -1, c))
                maze.addWall(Coordinates3D(level, rows - 1, c), Coordinates3D(level, rows, c))
            for r in range(rows):
                # Left and right boundaries
                maze.addWall(Coordinates3D(level, r, 0), Coordinates3D(level, r, -1))
                maze.addWall(Coordinates3D(level, r, cols - 1), Coordinates3D(level, r, cols))

        # Ensure boundaries do not cover entrances and exits
        for entrance in maze.getEntrances():
            if entrance.getRow() == -1:
                maze.removeWall(entrance, Coordinates3D(entrance.getLevel(), 0, entrance.getCol()))
            elif entrance.getCol() == -1:
                maze.removeWall(entrance, Coordinates3D(entrance.getLevel(), entrance.getRow(), 0))
            elif entrance.getRow() == rows:
                maze.removeWall(entrance, Coordinates3D(entrance.getLevel(), rows - 1, entrance.getCol()))
            elif entrance.getCol() == cols:
                maze.removeWall(entrance, Coordinates3D(entrance.getLevel(), entrance.getRow(), cols - 1))
