# -------------------------------------------------------------------
# PLEASE UPDATE THIS FILE.
# Pledge maze solver.
#
# __author__ = 'Jeffrey Chan'
# __copyright__ = 'Copyright 2024, RMIT University'
# -------------------------------------------------------------------


from maze.maze3D import Maze3D
from solving.mazeSolver import MazeSolver
from maze.util import Coordinates3D
import random


class PledgeMazeSolver(MazeSolver):
    """
    Pledge solver implementation.  You'll need to complete its implementation for task B.
    This solver uses the Pledge algorithm to navigate through a 3D maze.
    """
    def __init__(self):
        """
        Initializes the PledgeMazeSolver with necessary tracking variables.
        """
        super().__init__()
        self.arrow_direction_tracker = 'front'
        self.tracker = 0
        self.m_name = 'pledge'
        self.counter = 0
        self.dir = {
                    'front': Coordinates3D(0,1,0),
                    'left': Coordinates3D(0,0,-1),
                    'right': Coordinates3D(0,0,1),
                    'below': Coordinates3D(0,-1,0),
                    'up': Coordinates3D(1,0,0),
                    'down': Coordinates3D(-1,0,0)
                }
        self.currCellList = []


    def arrow_direction(self, prevCell: Coordinates3D, currCell: Coordinates3D):
        """
        Determines the direction of movement based on the previous and current cell coordinates.

        Args:
            prevCell (Coordinates3D): The previous cell.
            currCell (Coordinates3D): The current cell.
        """
        # a possible idea of checking from where we come is to record the prevCell
        # in order to figure out the direction of the arrow, you need to check from where did we come from?
        # i.e if we come from the down neighbor, that means the arrow is pointing up
        # if we come from the right neighbor, that means the arrow is pointing left
        # if we come from the left neighbor, that means the arrow is pointing right
        # if we come from the front neighbor, that means the arrow is pointing down


        # a possible idea of checking from where we come is to record the prevCell
        if  prevCell.getLevel() - currCell.getLevel() == 1:
            self.arrow_direction_tracker = 'up'
        elif prevCell.getLevel() - currCell.getLevel() == -1:
            self.arrow_direction_tracker = 'down'
        elif prevCell.getCol() - currCell.getCol() == 1:
            self.arrow_direction_tracker = 'left'
        elif prevCell.getCol() - currCell.getCol() == -1:
            self.arrow_direction_tracker = 'right'
        elif prevCell.getRow() - currCell.getRow() == 1:
            self.arrow_direction_tracker = 'below'
        elif prevCell.getRow() - currCell.getRow() == -1:
            self.arrow_direction_tracker = 'front'


    
    def neighbours_sort(self, neighbours: list[Coordinates3D]):
        """
        Sorts the list of neighbours based on the current direction tracker.

        Args:
            neighbours (list[Coordinates3D]): List of neighbouring cells.
        """
        # ['left','right','below','front',down,'up']
        # if self.arrow_direction_tracker == 'up':
        #     if len(neighbours) == 6:
        #         neighbours = [neighbours[4],neighbours[5],neighbours[0],neighbours[1],neighbours[2],neighbours[3]]
        #     elif len(neighbours) == 5:
        #         neighbours = [neighbours[4],neighbours[5],neighbours[0],neighbours[1],neighbours[2]]
            # ['left','right','below','front','up']

        if self.arrow_direction_tracker == 'up' or self.arrow_direction_tracker == 'down':
            # then make a random choice to either front,left,right,below
            x = ['front', 'left', 'right', 'below']
            self.arrow_direction_tracker = random.choice(x)
        
        if self.arrow_direction_tracker == 'front':
            if len(neighbours) == 6:
                neighbours[:] = [neighbours[0],neighbours[3],neighbours[1],neighbours[2],neighbours[4],neighbours[5]]
            elif len(neighbours) == 5:
                neighbours[:] = [neighbours[0],neighbours[3],neighbours[1],neighbours[2],neighbours[4]]
        elif self.arrow_direction_tracker == 'left':
            if len(neighbours) == 6:
                neighbours[:] = [neighbours[2],neighbours[0],neighbours[3],neighbours[1],neighbours[4],neighbours[5]]
            elif len(neighbours) == 5:
                neighbours[:] = [neighbours[2],neighbours[0],neighbours[3],neighbours[1],neighbours[4]]
        elif self.arrow_direction_tracker == 'right':
            if len(neighbours) == 6:
                neighbours[:] = [neighbours[3],neighbours[1],neighbours[2],neighbours[0],neighbours[4],neighbours[5]]
            elif len(neighbours) == 5:
                neighbours[:] = [neighbours[3],neighbours[1],neighbours[2],neighbours[0],neighbours[4]]
        elif self.arrow_direction_tracker == 'below':
            if len(neighbours) == 6:
                neighbours[:] = [neighbours[1],neighbours[2],neighbours[0],neighbours[3],neighbours[4],neighbours[5]]
            elif len(neighbours) == 5:
                neighbours[:] = [neighbours[1],neighbours[2],neighbours[0],neighbours[3],neighbours[4]]

    def solveMaze(self, maze: Maze3D, entrance: Coordinates3D):
        """
        Solves the 3D maze using the Pledge algorithm.

        Args:
            maze (Maze3D): The 3D maze to be solved.
            entrance (Coordinates3D): The entrance coordinates of the maze.
        """        
        prevCell: Coordinates3D = entrance
        visited : set[Coordinates3D] = set([prevCell])
        
        # enter the maze

        # # I need to make sure that the maze works for both entrances from the left side and from the bottom side
        if prevCell.getRow() == -1:
            currCell = Coordinates3D(prevCell.getLevel(), prevCell.getRow() + 1, prevCell.getCol())
            self.currCellList.append(currCell)
        elif prevCell.getCol() == -1:
            currCell = Coordinates3D(prevCell.getLevel(), prevCell.getRow(), prevCell.getCol() + 1)
            self.currCellList.append(currCell)

        
        listt = []
        while currCell not in maze.getExits():
            self.solverPathAppend(currCell, False)
            neighbours: list[Coordinates3D] = maze.neighbours(currCell)
            self.arrow_direction(prevCell, currCell) # there's no need to call as its changing the self.arrow_direction_tracker (global variable)
            self.neighbours_sort(neighbours)
            print(currCell.getLevel(), currCell.getRow(), currCell.getCol())
            print(f'direction: {self.arrow_direction_tracker}')
            neighbours_tuple = []
            for neighbour in neighbours:
                neighbours_tuple.append((neighbour.getLevel(),neighbour.getRow(),neighbour.getCol()))
            listt.append(self.counter)
            while self.counter == 0:
                print('stuck here1')
                # select a random direction to go to 
                x = ['front', 'left', 'right', 'below', 'up', 'down']
                self.arrow_direction_tracker = random.choice(x)
                neighbours: list[Coordinates3D] = maze.neighbours(currCell)
                self.neighbours_sort(neighbours)
                if not maze.hasWall(currCell, currCell + self.dir[self.arrow_direction_tracker]):
                    prevCell = currCell
                    currCell = currCell + self.dir[self.arrow_direction_tracker]
                    self.currCellList.append(currCell)
                    self.solverPathAppend(currCell, False)
                else:
                    while maze.hasWall(currCell, currCell + self.dir[self.arrow_direction_tracker]):
                        print('stuck here3')
                        self.counter -= 1
                        keys = list(self.dir.keys())
                        index = keys.index(self.arrow_direction_tracker) - 1
                        self.arrow_direction_tracker = keys[index]
                        if not maze.hasWall(currCell, currCell + self.dir[self.arrow_direction_tracker]):
                            prevCell = currCell
                            currCell = currCell + self.dir[self.arrow_direction_tracker]
                            self.currCellList.append(currCell)
                            self.solverPathAppend(currCell, False)
                            self.counter += 1  # Add to the counter as you changed direction successfully
                            break
            else:
                if len(neighbours) == 1:
                    if currCell in maze.getExits():# if we exit through the exit:
                        break
                    else:# if we exit through the entrace:
                        prevCell = currCell
                        currCell = neighbours[0]
                        self.currCellList.append(currCell)
                        self.solverPathAppend(currCell, False)
                # elif currCell in visited:
                #     currCell = prevCell
                # elif
                # i think the only thing remaining is to deal when stuck in a loop between levels
                # the way you should go about this is to check step by step testing/debugging 
                elif len(neighbours) == 6:
                    # can we go up or down?
                    if not maze.hasWall(currCell, neighbours[5]) and not maze.hasWall(currCell, neighbours[4]) and (currCell.getRow() - prevCell.getRow() == 1 or currCell.getRow() - prevCell.getRow() == -1 or currCell.getCol() - prevCell.getCol() == 1 or currCell.getCol() - prevCell.getCol() == -1):
                        # random choice between up and down
                        x = ['up', 'down']
                        y = random.choice(x)
                        if y == 'up':
                            prevCell = currCell
                            print(currCell)
                            currCell = neighbours[5]
                            self.currCellList.append(currCell)
                            self.tracker = 1
                            print(currCell)
                        else:
                            prevCell = currCell
                            print(currCell)
                            currCell = neighbours[4]
                            self.currCellList.append(currCell)
                            self.tracker = 1
                            print(currCell)
                    elif not maze.hasWall(currCell, neighbours[5]) and self.tracker == 0:
                        print('we go up')
                        prevCell = currCell
                        currCell = neighbours[5]
                        self.currCellList.append(currCell)
                        # self.solverPathAppend(currCell, False)
                        self.arrow_direction(prevCell, currCell) # there's no need to call as its changing the self.arrow_direction_tracker (global variable)
                        neighbours = maze.neighbours(currCell)
                        self.neighbours_sort(neighbours)
                        # is there a wall on the left?
                        print(currCell)
                        print(self.arrow_direction_tracker)
                        if maze.hasWall(currCell, neighbours[0]):  # yes
                            # is there a wall in front?
                            print('Theres a wall on the left!')
                            if maze.hasWall(currCell, neighbours[1]):  # yes,
                                # is there a wall on the right?
                                print('Theres a wall on the front')
                                if maze.hasWall(currCell, neighbours[2]):
                                    print('Theres a wall on the right')
                                    # is there a wall below? (dead-end)
                                    if maze.hasWall(currCell, neighbours[3]):
                                        print('Theres a wall on the below')  # yes,
                                        if len(neighbours) == 6:
                                            if prevCell.getLevel() - currCell.getLevel() == -1 and not maze.hasWall(currCell, neighbours[5]):
                                                # we just came from below
                                                # go up
                                                prevCell = currCell
                                                currCell = neighbours[5]
                                                self.currCellList.append(currCell)
                                                self.tracker = 1
                                            elif prevCell.getLevel() - currCell.getLevel() == 1 and not maze.hasWall(currCell, neighbours[4]):
                                                # we just came from up
                                                # go down
                                                prevCell = currCell
                                                currCell = neighbours[4]
                                                self.currCellList.append(currCell)
                                                self.tracker = 1
                                        elif prevCell.getLevel() - currCell.getLevel() == 1 and not maze.hasWall(currCell, neighbours[4]):
                                            # we just came from up
                                            # go down
                                            prevCell = currCell
                                            currCell = neighbours[4]
                                            self.currCellList.append(currCell)
                                            self.tracker = 1
                                    else:
                                        prevCell = currCell
                                        currCell = neighbours[3]
                                        self.currCellList.append(currCell)
                                else:
                                    prevCell = currCell
                                    currCell = neighbours[2]
                                    self.currCellList.append(currCell)
                            else:  # no,
                                #go forward
                                prevCell = currCell
                                currCell = neighbours[1]
                                self.currCellList.append(currCell)
                        else:  # no
                            prevCell = currCell
                            currCell = neighbours[0]
                            self.currCellList.append(currCell)
                    elif not maze.hasWall(currCell, neighbours[4]) and self.tracker == 0:
                        print('we go down')
                        # we can go down
                        prevCell = currCell
                        currCell = neighbours[4]
                        self.currCellList.append(currCell)
                        # self.solverPathAppend(currCell, False)
                        self.arrow_direction(prevCell, currCell) # there's no need to call as its changing the self.arrow_direction_tracker (global variable)
                        neighbours = maze.neighbours(currCell)
                        self.neighbours_sort(neighbours)
                        # is there a wall on the left?
                        if maze.hasWall(currCell, neighbours[0]):  # yes
                            # is there a wall in front?
                            print('Theres a wall on the left!')
                            if maze.hasWall(currCell, neighbours[1]):  # yes,
                                # is there a wall on the right (dead-end)?
                                print('Theres a wall on the front')
                                if maze.hasWall(currCell, neighbours[2]):
                                    print('Theres a wall on the right')
                                    # is there a wall below? (dead-end)
                                    if maze.hasWall(currCell, neighbours[3]):
                                        print('Theres a wall on the below')  # yes,
                                        if prevCell.getLevel() - currCell.getLevel() == -1 and not maze.hasWall(currCell, neighbours[5]):
                                            # we just came from below
                                            # go up
                                            prevCell = currCell
                                            currCell = neighbours[5]
                                            self.currCellList.append(currCell)
                                            self.tracker = 1
                                        elif prevCell.getLevel() - currCell.getLevel() == 1 and not maze.hasWall(currCell, neighbours[4]):
                                            # we just came from up
                                            # go down
                                            prevCell = currCell
                                            currCell = neighbours[4]
                                            self.currCellList.append(currCell)
                                            self.tracker = 1
                                    else:
                                        prevCell = currCell
                                        currCell = neighbours[3]
                                        self.currCellList.append(currCell)
                                else:
                                    prevCell = currCell
                                    currCell = neighbours[2]   
                                    self.currCellList.append(currCell)
                            else:  # no,
                                #go forward
                                prevCell = currCell
                                currCell = neighbours[1]
                                self.currCellList.append(currCell)
                        else:  # no
                            prevCell = currCell
                            currCell = neighbours[0]
                            self.currCellList.append(currCell)
                    else:
                        self.tracker = 0
                        # is there a wall on the left?
                        if maze.hasWall(currCell, neighbours[0]):  # yes
                            # is there a wall in front?
                            if maze.hasWall(currCell, neighbours[1]):  # yes,
                                # is there a wall on the right (dead-end)?
                                if maze.hasWall(currCell, neighbours[2]):  # yes,
                                    print('Theres a wall on the right')
                                    # is there a wall below? (dead-end)
                                    if maze.hasWall(currCell, neighbours[3]):
                                        print('Theres a wall on the below')  # yes,
                                        if prevCell.getLevel() - currCell.getLevel() == -1 and not maze.hasWall(currCell, neighbours[5]):
                                            # we just came from below
                                            # go up
                                            prevCell = currCell
                                            currCell = neighbours[5]
                                            self.currCellList.append(currCell)
                                            self.tracker = 1
                                        elif prevCell.getLevel() - currCell.getLevel() == 1 and not maze.hasWall(currCell, neighbours[4]):
                                            # we just came from up
                                            # go down
                                            prevCell = currCell
                                            currCell = neighbours[4]
                                            self.currCellList.append(currCell)
                                            self.tracker = 1
                                    else:
                                        prevCell = currCell
                                        currCell = neighbours[3]
                                        self.currCellList.append(currCell)
                                else:
                                    prevCell = currCell
                                    currCell = neighbours[2]   
                                    self.currCellList.append(currCell)
                            else:  # no,
                                #go forward
                                prevCell = currCell
                                currCell = neighbours[1]
                                self.currCellList.append(currCell)
                        else:  # no
                            prevCell = currCell
                            currCell = neighbours[0]
                            self.currCellList.append(currCell)
                elif len(neighbours) == 5:
                    # can we go up or down?
                    if not maze.hasWall(currCell, neighbours[4]) and self.tracker == 0:
                        print('we go up or down')
                        prevCell = currCell
                        currCell = neighbours[4]
                        self.currCellList.append(currCell)
                        # self.solverPathAppend(currCell, False)
                        self.arrow_direction(prevCell, currCell) # there's no need to call as its changing the self.arrow_direction_tracker (global variable)
                        neighbours = maze.neighbours(currCell)
                        self.neighbours_sort(neighbours)
                        # is there a wall on the left?
                        if maze.hasWall(currCell, neighbours[0]):  # yes
                            # is there a wall in front?
                            print('Theres a wall on the left!')
                            if maze.hasWall(currCell, neighbours[1]):  # yes,
                                # is there a wall on the right (dead-end)?
                                print('Theres a wall on the front')
                                if maze.hasWall(currCell, neighbours[2]):
                                    print('Theres a wall on the right')
                                    # is there a wall below? (dead-end)
                                    if maze.hasWall(currCell, neighbours[3]):
                                        print('Theres a wall on the below')  # yes,
                                        if prevCell.getLevel() - currCell.getLevel() == -1 and not maze.hasWall(currCell, neighbours[5]):
                                            # we just came from below
                                            # go up
                                            prevCell = currCell
                                            currCell = neighbours[5]
                                            self.currCellList.append(currCell)
                                            self.tracker = 1
                                        elif prevCell.getLevel() - currCell.getLevel() == 1 and not maze.hasWall(currCell, neighbours[4]):
                                            # we just came from up
                                            # go down
                                            prevCell = currCell
                                            currCell = neighbours[4]
                                            self.currCellList.append(currCell)
                                            self.tracker = 1
                                    else:
                                        prevCell = currCell
                                        currCell = neighbours[3]
                                        self.currCellList.append(currCell)
                                else:
                                    prevCell = currCell
                                    currCell = neighbours[2]   
                                    self.currCellList.append(currCell)
                            else:  # no,
                                #go forward
                                prevCell = currCell
                                currCell = neighbours[1]
                                self.currCellList.append(currCell)
                        else:  # no
                            prevCell = currCell
                            currCell = neighbours[0]
                            self.currCellList.append(currCell)
                    else:
                        self.tracker = 0
                        # is there a wall on the left?
                        if maze.hasWall(currCell, neighbours[0]):  # yes
                            # is there a wall in front?
                            if maze.hasWall(currCell, neighbours[1]):  # yes,
                                # is there a wall on the right (dead-end)?
                                if maze.hasWall(currCell, neighbours[2]):  # yes,
                                    print('Theres a wall on the right')
                                    # is there a wall below? (dead-end)
                                    if maze.hasWall(currCell, neighbours[3]):
                                        print('Theres a wall on the below')  # yes,
                                        if len(neighbours) == 6:
                                            if prevCell.getLevel() - currCell.getLevel() == -1 and not maze.hasWall(currCell, neighbours[5]):
                                                # we just came from below
                                                # go up
                                                prevCell = currCell
                                                currCell = neighbours[5]
                                                self.currCellList.append(currCell)
                                                self.tracker = 1
                                            elif prevCell.getLevel() - currCell.getLevel() == 1 and not maze.hasWall(currCell, neighbours[4]):
                                                # we just came from up
                                                # go down
                                                prevCell = currCell
                                                currCell = neighbours[4]
                                                self.currCellList.append(currCell)
                                                self.tracker = 1
                                    
                                        elif prevCell.getLevel() - currCell.getLevel() == 1 and not maze.hasWall(currCell, neighbours[4]):
                                            # we just came from up
                                            # go down
                                            prevCell = currCell
                                            currCell = neighbours[4]
                                            self.currCellList.append(currCell)
                                            self.tracker = 1
                                    else:
                                        prevCell = currCell
                                        currCell = neighbours[3]
                                        self.currCellList.append(currCell)
                                else:
                                    prevCell = currCell
                                    currCell = neighbours[2]  
                                    self.currCellList.append(currCell) 
                            else:  # no,
                                #go forward
                                prevCell = currCell
                                currCell = neighbours[1]
                                self.currCellList.append(currCell)
                        else:  # no
                            prevCell = currCell
                            currCell = neighbours[0]
                            self.currCellList.append(currCell)
                visited.add(currCell)

        # ensure we are currently at the exit
        if currCell in maze.getExits():
            print(f'Total Cost: {len(self.currCellList)}')
            unique_items_count = len(set(self.currCellList))
            print(f'Unique Cost: {unique_items_count}')
            self.solved(entrance, currCell)
