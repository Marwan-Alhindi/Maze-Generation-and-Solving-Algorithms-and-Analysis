# -------------------------------------------------------------------
# PLEASE UPDATE THIS FILE.
# Task C solver.
#
# __author__ = 'Jeffrey Chan'
# __copyright__ = 'Copyright 2024, RMIT University'
# -------------------------------------------------------------------


import heapq
from collections import deque
from maze.maze3D import Maze3D
from solving.mazeSolver import MazeSolver
from maze.util import Coordinates3D

class TaskCMazeSolver(MazeSolver):
    """
    Task C solver implementation. You'll need to complete its implementation for task C.
    This solver uses Dijkstra's algorithm to find the shortest path in a 3D maze.
    """

    def __init__(self):
        """
        Initializes the TaskCMazeSolver with necessary tracking variables.
        """
        super().__init__()
        self.m_name = "taskC"
        self.best_path = []

    def solveMaze(self, maze: Maze3D):
        # we call the solve maze call without the entrance.
        # DO NOT CHANGE THIS METHOD
        self.solveMazeTaskC(maze)
        

    def solveMazeTaskC(self, maze: Maze3D):
        """
        Solve the maze, used by Task C.
        This version of solveMaze does not provide a starting entrance, and as part of the solution, 
        the method should find the entrance and exit pair (see project specs for requirements of this task).
        TODO: Please complete this implementation for task C. You should call maze.solved(...) to update 
        which entrance and exit you used for task C.

        @param maze: Instance of maze to solve.
        """
        entrances = maze.getEntrances()
        exit_count = len(maze.getExits())  # Number of exits, but not their locations
        
        # Initial variables to store the best path
        min_cost = float('inf')
        best_entrance = None
        best_exit = None
        best_path = []

        # Use Dijkstra's algorithm to explore the maze from all entrances
        for entrance in entrances:
            # Priority queue to keep track of the next node to explore
            pq = [(0, 0, entrance)]  # (modified cost, cells explored, node)
            heapq.heapify(pq)
            visited = set()
            path_cost = {entrance: 0}
            cells_explored = {entrance: 0}
            parent = {entrance: None}

            while pq:
                modified_cost, cells, current = heapq.heappop(pq)

                # Mark the node as visited
                if current in visited:
                    continue
                visited.add(current)
                # If current cell is an exit
                if self.isExit(current, maze, entrances):
                    total_cost = path_cost[current]  # Distance from entrance to exit
                    total_cells_explored = cells  # Total cells explored
                    modified_total_cost = total_cost + total_cells_explored
                    if modified_total_cost < min_cost:
                        min_cost = modified_total_cost
                        best_entrance = entrance
                        best_exit = current
                        # Reconstruct the path from exit to entrance
                        best_path = []
                        cell = current
                        while cell is not None:
                            best_path.append(cell)
                            cell = parent[cell]
                        best_path.reverse()
                    
                    # If all exits are found, break out of the loop
                    if len([cell for cell in visited if self.isExit(cell, maze, entrances)]) == exit_count:
                        break

                # Explore neighbors
                for neighbor in maze.neighbours(current):
                    if neighbor not in visited and not maze.hasWall(current, neighbor):
                        new_cost = path_cost[current] + 1  # Assuming each move has a cost of 1
                        new_cells = cells + 1  # Increment the number of cells explored
                        modified_new_cost = new_cost + new_cells
                        if neighbor not in path_cost or modified_new_cost < (path_cost[neighbor] + cells_explored[neighbor]):
                            path_cost[neighbor] = new_cost
                            cells_explored[neighbor] = new_cells
                            heapq.heappush(pq, (modified_new_cost, new_cells, neighbor))
                            parent[neighbor] = current


        # Append the cells of the best path found
        for cell in best_path:
            self.solverPathAppend(cell, False)
            self.best_path.append(cell)

        # If we found a valid entrance-exit pair
        if best_entrance and best_exit:
            print(f'modified_total_cost: {modified_cost}')
            self.x = True
            self.solved(best_entrance, best_exit)

    
    def isExit(self, cell: Coordinates3D, maze: Maze3D, entrances: list) -> bool:
        """
        Determines if a cell is an exit.
        A cell is an exit if it is outside the maze bounds and not in entrances.

        @param cell: The cell to check.
        @param maze: The maze instance.
        @param entrances: List of entrance cells.
        @return: True if the cell is an exit, False otherwise.
        """
        if cell in entrances:
            return False

        level = cell.getLevel()
        row = cell.getRow()
        col = cell.getCol()

        if row < 0 or row >= maze.rowNum(level) or col < 0 or col >= maze.colNum(level):
            return True
        
        return False